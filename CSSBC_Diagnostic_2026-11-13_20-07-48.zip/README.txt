﻿CSS Bot Community diagnostic bundle
Created: 2026-11-13_20-07-48
Review included files before sharing. This collector does not intentionally collect usernames,
machine identifiers, network addresses, chat, screenshots, or process command lines.
